<?php
require_once "includes\db.php"; // Ensure this connects using PDO

// Hash the password before storing it
$password = password_hash('admin123', PASSWORD_DEFAULT);

try {
    $sql = "INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, :role)";
    $stmt = $pdo->prepare($sql);

    // Bind parameters to prevent SQL injection
    $stmt->bindParam(":username", $username, PDO::PARAM_STR);
    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
    $stmt->bindParam(":password", $password, PDO::PARAM_STR);
    $stmt->bindParam(":role", $role, PDO::PARAM_STR);

    // Define the values for the placeholders
    $username = 'xa';
    $email = 'xa@example.com';
    $role = 'owner';

    $stmt->execute();

    echo "✅ Admin user added successfully!"; 
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>