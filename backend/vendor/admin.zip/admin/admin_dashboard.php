<?php echo '<h2>admin_dashboard.Php</h2>'; ?>
<?php include 'includes/config.php'; ?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>
<?php include 'includes/navbar.php'; ?>

<main class="content">
    <header>
        <h2>Dashboard</h2>
        
    </header>

    <section class="dashboard-metrics">
    <?php
function getCount($conn, $query, $label) {
    $result = $conn->query($query);
    if (!$result) {
        echo "<strong>Query Error ($label):</strong> " . $conn->error . "<br>";
        return 0;
    }
    return $result->fetch_assoc()['count'];
}

$staffs = getCount($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'staff'", 'staffs');
$dogs = getCount($conn, "SELECT COUNT(*) as count FROM pets WHERE species = 'dog'", 'dogs');
$cats = getCount($conn, "SELECT COUNT(*) as count FROM pets WHERE species = 'cat'", 'cats');
$clients = getCount($conn, "SELECT COUNT(*) as count FROM users WHERE role = 'client'", 'clients');

// No sales table found, setting default value
$sales = 0; // Change this if you later create a sales table
?>

        <div class="dashboard-header">
            <h2>Welcome, Admin!</h2>
            <p>Here's a quick overview of your dashboard.</p>
        </div>

        <!-- Metric Cards -->
        <div class="metric">
            <div class="metric-value"><?= $staffs ?></div>
            <div class="metric-label">Number of Staffs</div>
        </div>
        <div class="metric">
            <div class="metric-value"><?= $dogs ?></div>
            <div class="metric-label">Number of Dogs</div>
        </div>
        <div class="metric">
            <div class="metric-value"><?= $cats ?></div>
            <div class="metric-label">Number of Cats</div>
        </div>
        <div class="metric">
            <div class="metric-value"><?= $clients ?></div>
            <div class="metric-label">Number of Pet Owners</div>    
        </div>
        <div class="metric">
            <div class="metric-value">GHS <?= number_format($sales, 2) ?></div>
            <div class="metric-label">Total Sales Today</div>
        </div>
    </section>

    <!-- Appointments Calendar (placeholder) -->
    <section class="appointments-calendar">
    <h3>Appointments Calendar</h3>
    <div id="calendar"></div>
</section>

    <!-- FullCalendar JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.11.3/main.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    if (!calendarEl) {
        console.error("Calendar element not found!");
        return;
    }

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: 'includes/fetch_appointments.php', // Fetch JSON from PHP
        headerToolbar: {
            left: 'prev,today,next',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
        },
        eventColor: '#3788d8'
    });

    calendar.render();
});
</script>


</div>

    <!-- Vaccination Graph (placeholder) -->
    <section class="vaccination-graph">
        <h3>Vaccination Graph</h3>
        <canvas id="vaccinationChart"></canvas>
    </section>

    <!-- Pet Owners and Pets -->
    <section>
        <h3>Pet Owners & Their Registered Pets</h3>
        <div id="ownersPetsTable">
            <!-- We'll populate this with PHP later -->
        </div>
    </section>

    <!-- Pets Registered by Admin -->
    <section>
        <h3>Pets Registered by Admin</h3>
        <div id="petsByAdmin">
            <!-- We'll populate this dynamically -->
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
